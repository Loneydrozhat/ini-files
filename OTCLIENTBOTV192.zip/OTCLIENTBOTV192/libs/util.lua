function getBestAreaPosition(ignorePlayers, minCount, range)
    local player = g_game.getLocalPlayer()
    if not player then return end
    local playerPos = player:getPosition()
    local bestSqm = {x, y, z, amount = 0}
    local creatures = g_game.getCreatures()
    for a = 0, 7 do
        local i, j = -a, -a
        while j <= a do
            i = -a
            while i <= a do
                if (math.abs(j) == a or math.abs(i) == a) then
                    local posx, posy = playerPos.x + i, playerPos.y + j
                    local tile = g_map.getTile(Position.new(posx, posy, playerPos.z))
                    if tile and tile:isShootable() and tile:isWalkable() and tile:isPathable() then
                        local tempm, tempp = 0, 0
                        for _, creature in ipairs(creatures) do
                            if creature:getName() ~= player:getName() then
                                local creaturePos = creature:getPosition()
                                if creature:isMonster() and tile:getPosition():isInRange(creature:getPosition(), range, range) then
                                    tempm = tempm + 1
                                elseif creature:isPlayer() then
                                    tempp = tempp + 1
                                end
                            end
                        end
                        if tempm > bestSqm.amount and (ignorePlayers or tempp == 0) then
                            bestSqm.x, bestSqm.y, bestSqm.z, bestSqm.amount = posx, posy, playerPos.z, tempm
                        end
                    end
                end
				if math.abs(j) ~= a then
					i = i+2*a
				else
					i = i + 1
				end
            end
			j = j + 1
        end
    end
    if bestSqm.amount < minCount then
        return nil
    end
    
	return Position.new(bestSqm.x, bestSqm.y, bestSqm.z)
end