--[[
    dofile "libs/example.lua" -- calling this function in your script will allow to use every declared function and variable inside this file
    libsExample() -- calling the function from loaded library
]]

function libsExample()
  print("it does work")
end
