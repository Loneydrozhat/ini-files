-- do not edit

function Position:equals(pos2)
  return self.x == pos2.x and self.y == pos2.y and self.z == pos2.z
end

function Position:greaterThan(pos2, orEqualTo)
  if orEqualTo then
    return self.x >= pos2.x or self.y >= pos2.y or self.z >= pos2.z
  else
    return self.x > pos2.x or self.y > pos2.y or self.z > pos2.z
  end
end

function Position:lessThan(pos2, orEqualTo)
  if orEqualTo then
    return self.x <= pos2.x or self.y <= pos2.y or self.z <= pos2.z
  else
    return self.x < pos2.x or self.y < pos2.y or self.z < pos2.z
  end
end

function Position:isInRange(pos2, xRange, yRange)
  return math.abs(self.x-pos2.x) <= xRange and math.abs(self.y-pos2.y) <= yRange and self.z == pos2.z;
end

function Position:isValid()
  return not (self.x == 65535 and self.y == 65535 and self.z == 255)
end

function Position:distance(pos2)
  return math.sqrt((pos2.x - self.x) ^ 2 + (pos2.y - self.y) ^ 2)
end

function Position:manhattanDistance(pos2)
  return math.abs(pos2.x - self.x) + math.abs(pos2.y - self.y)
end